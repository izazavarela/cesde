<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="ie=edge" />
	<meta name= "viewport" content= "width=device-width initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>

<style type="text/css">
form input{
  width:30%;
  padding:4px 8px;
  margin-top:4px;
  border:1px solid #000;
  border-radius:5px;
  display:block;
}

form{
  width: 90%;
  padding: 5%;
  margin: 0 auto;
  text-align: left;
  align-items: center;
  border: PowderBlue 1px solid;
  border-radius: 20px;
  background-color: #D4E6F1;
    }

body{
  font-family: Arial, Helvetica, Sans-serif;
  color: black;
  font-size: 16px;
}
.mss{
  width: 30%;
  margin-left: 60px;
  border-radius: 8px;
}
select{
  appearance: none;
  width: 100%;
  height: 38px;
  cursor: pointer;
  display: block;
  padding: 7px 10px;
  background: #f0f0f0;
	font-size: 1em;
	color: #999;
  font-family: 
	'Quicksand', sans-serif;
	  border:2px solid rgba(0,0,0,0.2);
    border-radius: 12px;
    position: relative;
    transition: all 0.25s ease;
}
</style>
<!-- Comienza el contenido de la pagina -->
<body>
<br>
<div class="container">
<div class="mss">
<?php if($this->session->flashdata('status')) :?>
<div class="alert alert-success alert-dismissable">
<button type="button" class="close" data-dismiss="alert">&times;</button>
  <?= $this->session->flashdata('status');?>
</div>
  <?php endif; ?>
  <?php if($this->session->flashdata('status1')) :?>
<div class="alert alert-danger alert-dismissable">
<button type="button" class="close" data-dismiss="alert">&times;</button>
  <?= $this->session->flashdata('status1');?>
</div>
  <?php endif; ?>
</div>
<!-- Encabezado de la pagina -->
  <form class="form" enctype="multipart/form-data" action="<?php echo base_url('Cursos/curso/guardar/')?>" method="post">
  <center><h3>REGISTRAR CURSOS.</h3></center> 
  <br><br>         
  <div class="form-row align-items-center ">
      <div class="col-md-3">
        <label for="">Codigo</label>
        <input type="text" class="form-control" name="pkcodigo" id="pkcodigo">
      </div>
      <div class="col-md-3">
        <label for="">Nombre</label>
        <input type="text" class="form-control" name="nombre" id="nombre" required>
      </div>
      <div class="col-md-3">
        <label for="">Descripcion</label>
        <input type="text" class="form-control" name="descripcion" id="descripcion" required>
      </div>
      <div class="col-md-3">
        <label for="">Semanas</label>
        <input type="text" class="form-control" name="duracion_semanas" id="duracion_semanas" required>
      </div>
      </div>
      <div class="form-row align-items-center ">
      <div class="col-md-3">
        <label for="">precio</label>
        <input type="text" class="form-control" name="precio" id="precio" required>
      </div>
    <div class="col-md-3">
      <label for="">Docente</label>
    <select name="fkcodigo_docente" >
    <?php foreach ($datosDocente as $key): ?>
        <option value="<?php echo $key->pkcodigo?>"><?php echo $key->nombre?></option>
        <?php endforeach ?>  
    </select>
    </div>
        <div class="col-md-3">
        <label for="">fecha_inicio</label>
        <input type="text" class="form-control" name="fecha_inicio" id="fecha_inicio">
      </div>
    </div>
    <br>
    <div class="form-group">
      <button type="submit" class="btn btn-success btn-flat">Guardar</button>
    </div>
  </form>
  </div>
</body>



