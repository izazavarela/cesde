<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <title>Ingresa al sistema salud vida</title>
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
	<meta name= "viewport" content= "width=device-width initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="<?=base_url()?>static/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?=base_url()?>static/css/flat-ui.min.css">
</head>
<style>
.container{
    display: flex;
    align-items: center;
    justify-content: center;
}
.form {
  margin: 85px;
  width: 400px;
  background: #F7F9F9;
  opacity: 3.0;
}
h2{
    font-family: "Times New Roman", Times, serif;
    font-size: 40px;
    color: black;
}
#btni{
    position: relative;
    display: table-cell;
  vertical-align: middle; 
}
</style>
<body>
    <div class="container">
        <div class="row">
                <form action="login/entrar" method="POST" class="border p-5 form">
                <?php if($this->session->flashdata('error')) :?>
                <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <?= $this->session->flashdata('error');?>
                </div>
                <?php endif; ?>     
                <h2 class="text-center">Inicie Sesión.</h2>
                    <div class="form-group">
                        <label for="usuario"></label>
                        <input type="text" name="PKIdentidad" id="Usuario" class="form-control" placeholder="Usuario">
                    </div>
                    <div class="form-group">
                        <label for="contraseña"></label>
                        <input type="password" name="Password" id="Password" class="form-control" placeholder="Password">
                    </div>
                    <br>
                    <div id="btni">
                    <input type="submit" value="Ingresar" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>

    </div>
</body>