<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Medico extends CI_Controller {

	public function __construct(){
		parent:: __construct();
    $this->load->model("Cursos_model");

	}

  public function index()
	{
		$datos['datosDocente'] = $this->Cursos_model->getDocente();
		$this->load->view('template/menu');
		$this->load->view('cursos/añadir', $datos);
		$this->load->view('template/pie');   
	}

	public function add()
	{		
		$this->load->view('template/cabeza');
		$this->load->view('template/menu');
		$this->load->view('usuarios/add');
		$this->load->view('template/pie');
	}
	
	public function edit($curso){

		$data  = array(
			'tblcursos' => $this->Usuarios_model->getUsuario($curso), 
			
		);
		$this->load->view('template/cabeza');
		$this->load->view('template/menu');
		$this->load->view('cursos/edit',$data);
		$this->load->view('template/pie');
	}

	public function guardar(){	
                
				$cursos['nombre'] = $_POST['nombre'];
				$cursos['descripcion'] = $_POST['descripcion'];
				$cursos['duracion_semanas'] = $_POST['duracion_semanas'];
				$cursos['precio'] = $_POST['precio'];
				$cursos['fecha_inicio'] = time("Y-m-d H:i");
				$cursos['fkcodigo_docente'] = $_POST['precio'];                    

				$this->load->model('Cursos_model');
				$this->Cursos_model->guardar($cursos);
				$this->session->set_flashdata('status', 'Curso registrado exitosamente...');
				redirect(base_url()."Cursos/Curso/index");                
            }
       			

