<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct(){
		parent:: __construct();
		$this->load->model('Login_model');

	}
	public function index()
	{
		$this->load->view('login');
	}

	public function entrar()
	{
		// if($this->session->userdata('user')){
		// 	redirect('Bienvenido');
		// }

		$usuario = $_POST['PKIdentidad'];
		$password = md5($_POST['Password']);
		$pass = $this->Login_model->getUsuario($usuario, $password);
		
		if(isset($_POST['Password']))
        {
		$this->load->model('Login_model');
            if($this->Login_model->getUsuario($_POST['PKIdentidad'], $_POST['Password'])){
				$this->session->set_userdata('user', $_POST['PKIdentidad']);
				redirect('Bienvenido');
            }
            else
            {
				$this->session->set_flashdata('error', 'Usuario o contraseña incorrectos.');
				redirect('login');                
            }
        }

	}

	public function salir()
	{
		$this->session->sess_destroy();

		redirect(base_url('login'));
	}
}
