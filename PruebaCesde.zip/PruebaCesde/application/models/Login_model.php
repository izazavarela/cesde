<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

public function __construct(){
  parent::__construct();
}


public function getUsuario($usuario,$password)
  {
    $this->db->where('PKIdentidad',$usuario);
    $this->db->where('Password',$password);
    $this->db->where('FKCodigo_tblestados', 1);
    return $this->db->get('tblusuarios')->row();
  }
}
