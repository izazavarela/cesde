<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cursos_model extends CI_Model {

    
        public function getCursos(){
        $this->db->select('*');
        $this->db->join('tbldocentes', 'tbldocentes.pkcodigo = tblcursos.fkcodigo_docentes', 'INNER');
        $this->db->from('tblcursos');
        $consulta = $this->db->get();
        $resultado = $consulta->result();
        return $resultado;      
            }

        public function getDocente(){

            $query = $this->db->query("select pkcodigo, nombres from tbldocentes");
            return $query->result();
        } 

        public function guardar($cursos)
        {                       
         $this->db->insert('tblcursos', $cursos);                
        }

        public function eliminar($pkcodigo){        
        $this->db->where('pkcodigo',$codigo);
        $this->db->delete('tblcursos');
        }

        public function actualizar($cursos)
        {
        $this->db->set('nombre',$cursos['nombre']);
        $this->db->set('descripcion',$cursos['descripcion']);
        $this->db->set('duracion_semanas',$cursos['duracion_semanas']);
        $this->db->set('precio',$cursos['precio']);
        $this->db->set('fecha_inicio', $cursos['fecha_inicio']);
        $this->db->set('fkcodigo_docente', $cursos['fkcodigo_docente']);

        
        $this->db->where('pkcodigo',$cursos['pkcodigo']);
        $this->db->update('tblcursos');

    }

}


 